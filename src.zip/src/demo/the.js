// Create your app with 'youtube-embed' dependency

var myApp = angular.module('myApp', ['youtube-embed', 'ngRoute', 'hljs']);

myApp.config(['$routeProvider', function($routeProvider) {
  $routeProvider
   .when('/', {
    templateUrl: 'demo/nextfile.html',
    controller: 'TheCtrl'
  })
  .when('/advanced', {
    templateUrl: 'demo/advanced.html',
    controller: 'AdvancedCtrl'
  })
  .otherwise('/');
}]).run(function ($rootScope, $window) {
  $rootScope.$on('$routeChangeSuccess', function () {
    $window.scrollTo(0, 0);
  });
});

// Inside your controller...
myApp.controller('TheCtrl', function ($scope) {
    // have a video ID
    $scope.theBestVideo = 'o_f2YxM3tS4';

    // or a URL
    $scope.anotherGoodOne = 'https://www.youtube.com/watch?v=18-xvIjH8T4';
});

myApp.controller('AdvancedCtrl', function ($scope) {

    $scope.specifiedTime = {
        url: 'https://www.youtube.com/watch?v=e-5obm1G_FY',
        player: null
    };

    $scope.looper = {
        video: '0tj6VLuSowQ',
        player: null
    };

    $scope.$on('youtube.player.ended', function ($event, player) {
        if (player === $scope.looper.player) {
            player.playVideo();
        }
    });

    $scope.custom = {
        video: 'gQRsgFw7tcg',
        player: null,
        vars: {
            controls: 0
        }
    };

    $scope.conditional = {
        video: 'GKRQC4fLNHs',
        visible: false,
        toggle: function () {
            this.visible = !this.visible;
        },
        vars: {
            autoplay: 1
        }
    };

    $scope.playlist = {
        vars: {
            list: 'PLYxzS__5yYQmX2bItSRCqwiQZn5dIL1gt'
        }
    };

    var first = 'AASd5ewKNSw';
    var second = 'zmEG-5zEmPw';
    $scope.dynamic = {
        video: first,
        change: function () {
            if ($scope.dynamic.video === first) {
                $scope.dynamic.video = second;
            } else {
                $scope.dynamic.video = first;
            }
        }
    };
});
